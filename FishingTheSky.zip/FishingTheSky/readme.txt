FishingTheSky for XMMS

Clean nice XMMS theme to fit the Fishing The Sky 2 GTK2/Metacity themes

-- Mattias Sundberg <mattias.s@telia.com>
