Mac amp v1.0

--------------------------------------------

16/09/03

Skin by Matuhin Filia.
The design of MacOS is impressive, so that`s a good idea to make such skin. I used to work on WinXP, but when got opportunity to work on MacOS for some time, I simply had no words to tell about it`s amazing interface! Now I changed the WinXP theme on my PC to MacOS-like (I used Style XP for this stuff).

Thanks for downloading it,  U really make me smile.

Skin is fully compatible with winamp 2.9 (featuring video and library window). If You have got older version of Winamp - hurry up on www.winamp.com and download last version!

Mail to me with questions on FILIACOM@NAROD.RU and visit my own web-site on HTTP://FILIACOM.NAROD.RU, where You will find lots of stuff (Skins, Desktops, Scores, Flash movies ...). If You speak russian there is a russian version of my web-site.


Other skins by me on winamp.com

Filiacom

Masyania