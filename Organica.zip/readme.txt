
::Breedamp organica::
By Goochtek

All (c) Jon Gooch 2001

Just like to say a big thanks to all the breed crew
for giving me the opportunity to do this.

--------------------------------------------------------------------

check out these sites = 

www.deviantart.com
www.monaux.com
www.wastedyouth.org
www.endeffect.com
www.razorart.com
www.breedart.org
www.awedigi.com
